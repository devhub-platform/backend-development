<?php

use App\Models\User;
use App\Services\OneSignalService;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Redis;

use Illuminate\Support\Facades\Http;

use Lepresk\LaravelOnesignal\Facades\OneSignal;
use Lepresk\LaravelOnesignal\PushMessage;

// Get first existing user ID
$message = (new PushMessage())
    ->withTitle('Hello World')
    ->withBody('This is my first push notification!')
    ->toExternalUserIds([1000]); // Use actual user ID

$response = OneSignal::send($message);

if ($response->isSuccessful()) {
    echo "✓ Notification sent successfully!\n";
    echo "  Notification ID: " . $response->getNotificationId() . "\n";
    echo "  Recipients: " . $response->getRecipients() . "\n";
} else {
    \Illuminate\Support\Facades\Log::error('Failed to send notification', [
        'error' => $response->getError(),
        'response' => $response->getBody(),
    ]);
    echo "✗ Failed to send notification\n";
    echo "  Error: " . $response->getError() . "\n";
}
