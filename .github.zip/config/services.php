<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'google' => [
        'client_id' => env('GOOGLE_CLIENT_ID'),
        'client_secret' => env('GOOGLE_CLIENT_SECRET'),
        'redirect' => env('GOOGLE_REDIRECT_URL'),
    ],

    'github' => [
        'client_id' => env('GITHUB_CLIENT_ID'),
        'client_secret' => env('GITHUB_CLIENT_SECRET'),
        'redirect' => env('GITHUB_REDIRECT_URL'),
    ],

    'hackai' => [
        'base_url' => env('HACKAI_BASE_URL'),
        'token'    => env('HACKCLUB_API_KEY'),
    ],


    'hackClub' => [
        'api_key' => env('HACKCLUB_API_KEY'),
    ],

    'llama' => [
        'api_key' => env('LLAMA_KEY'),
        'base_url' => env('LLAMA_API_URL'),
        'host' => env('LLAMA_API_HOST')
    ],

    'summarize' => [
        'api_key' => env('SUMMARIZE_KEY'),
        'host' => env('SUMMARIZE_HOST')
    ],

    'mail' => [
        'admin_email_1' => env('ADMIN_EMAIL1'),
        'admin_email_2' => env('ADMIN_EMAIL2'),
    ],

    'piston' => [
        'api_key' => env('PISTON_API_KEY'),
        'base_url' => env('PISTON_API_URL', 'https://emkc.org/api/v2/piston'),
    ],
];
