<?php

namespace App\Services;

use App\Models\User;
use Google_Client;
use Illuminate\Support\Facades\Log;
use Tymon\JWTAuth\Facades\JWTAuth;

class GoogleAuthService
{

    public function verifyIdToken(string $idToken): array|false
    {
        try {
            $client = new Google_Client([
                'client_id' => config('services.google_mobile.client_id')
            ]);

            $payload = $client->verifyIdToken($idToken);

            if (!$payload) {
                Log::warning('Invalid Google ID token received');
                return false;
            }

            return $payload;
        } catch (\Throwable $e) {
            Log::warning('Google token verification failed: ' . $e->getMessage());
            return false;
        }
    }

    public function isEmailVerified(array $payload): bool
    {
        return isset($payload['email_verified']) && $payload['email_verified'] === true;
    }


    public function extractUserData(array $payload): array
    {
        $email = $payload['email'];

        return [
            'email' => $email,
            'name' => $payload['name'] ?? str()->before($email, '@'),
            'avatar' => $payload['picture'] ?? null,
            'google_id' => $payload['sub'],
            'given_name' => $payload['given_name'] ?? null,
            'family_name' => $payload['family_name'] ?? null,
        ];
    }

    public function findOrCreateUser(array $userData): User
    {
        $existingUser = User::where('email', $userData['email'])->first();

        if ($existingUser) {
            return $this->updateExistingUser($existingUser, $userData);
        }

        return $this->createNewUser($userData);
    }

    protected function updateExistingUser(User $user, array $userData): User
    {
        if (!$user->provider_id || $user->provider_id !== $userData['google_id']) {
            $user->update([
                'provider_id' => $userData['google_id'],
                'avatar_url' => $userData['avatar'] ?? $user->avatar_url,
                'email_verified_at' => $user->email_verified_at ?? now(),
            ]);
        }

        Log::info('Existing user logged in via Google', [
            'user_id' => $user->id,
            'email' => $user->email
        ]);

        return $user->fresh();
    }

    protected function createNewUser(array $userData): User
    {
        $username = $this->generateUniqueUsername($userData['email']);

        $user = User::create([
            'email' => $userData['email'],
            'name' => $userData['name'],
            'username' => $username,
            'website_url' => null,
            'role' => 'user',
            'bio' => null,
            'github_username' => null,
            'provider_id' => $userData['google_id'],
            'password' => bcrypt(str()->random(16)),
            'avatar_url' => $userData['avatar'],
            'email_verified_at' => now(),
        ]);

        Log::info('New user created via Google', [
            'user_id' => $user->id,
            'email' => $user->email
        ]);

        return $user;
    }

    protected function generateUniqueUsername(string $email): string
    {
        $baseUsername = str()->slug(str()->before($email, '@'));
        $username = $baseUsername . '_' . rand(1000, 9999);

        while (User::where('username', $username)->exists()) {
            $username = $baseUsername . '_' . rand(1000, 9999);
        }

        return $username;
    }

    public function generateToken(User $user, int $ttlMinutes = 43200): string
    {
        JWTAuth::factory()->setTTL($ttlMinutes);
        return JWTAuth::fromUser($user);
    }

    public function authenticateWithIdToken(string $idToken): array
    {
        $payload = $this->verifyIdToken($idToken);

        if (!$payload) {
            return [
                'success' => false,
                'message' => 'Invalid Google token',
                'error' => 'Token verification failed'
            ];
        }

        if (!$this->isEmailVerified($payload)) {
            Log::warning('Unverified email attempted Google login', [
                'email' => $payload['email'] ?? 'unknown'
            ]);

            return [
                'success' => false,
                'message' => 'Email not verified with Google',
                'error' => 'Please verify your email with Google first'
            ];
        }

        $userData = $this->extractUserData($payload);

        $user = $this->findOrCreateUser($userData);

        $token = $this->generateToken($user, 60 * 24 * 30);

        return [
            'success' => true,
            'message' => 'Login successful using Google',
            'data' => [
                'user' => $user,
                'token' => $token,
                'token_type' => 'bearer',
                'expires_in' => 60 * 24 * 30 // minutes
            ]
        ];
    }
}

