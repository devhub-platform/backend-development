<?php

namespace App\Http\Requests\PostsRequests;

use Illuminate\Foundation\Http\FormRequest;

class PostStoreRequest extends FormRequest
{
    public function rules()
    {
        return [
            'title' => 'required|string|max:255',
            'content' => 'required|string|max:5000',
            'image_url' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'cover_image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'slug' => 'sometimes|string|unique:posts,slug',
            'created_at' => 'nullable|date',
            'updated_at' => 'nullable|date',
            'status' => 'nullable|in:draft,published',
            'read_time' => 'nullable|integer|min:1|max:59',
        ];
    }

    public function authorize()
    {
        return true;
    }
}
