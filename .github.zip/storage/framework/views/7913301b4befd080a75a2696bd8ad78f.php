<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\course laravel\devhub\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>