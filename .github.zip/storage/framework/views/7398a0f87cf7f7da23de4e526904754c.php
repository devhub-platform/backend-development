<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Dashboard - Mailbox</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #6366f1;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f8fafc;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }

        .sidebar {
            background: linear-gradient(135deg, var(--primary) 0%, #4f46e5 100%);
            min-height: 100vh;
            color: white;
            padding: 2rem 0;
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            margin-bottom: 2rem;
        }

        .sidebar-header h2 {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0;
        }

        .sidebar-nav {
            list-style: none;
            padding: 0 1rem;
        }

        .sidebar-nav li {
            margin-bottom: 0.5rem;
        }

        .sidebar-nav a {
            display: block;
            padding: 0.75rem 1rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            border-radius: 0.5rem;
            transition: all 0.3s ease;
        }

        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }

        .main-content {
            margin-left: 280px;
            padding: 2rem;
        }

        .header {
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            font-size: 2rem;
            font-weight: 700;
            color: #1e293b;
            margin: 0;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: white;
            padding: 2rem;
            border-radius: 1rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            border-top: 4px solid var(--primary);
        }

        .stat-card:hover {
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            transform: translateY(-2px);
        }

        .stat-card.danger {
            border-top-color: var(--danger);
        }

        .stat-card.success {
            border-top-color: var(--success);
        }

        .stat-card.warning {
            border-top-color: var(--warning);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 0.5rem;
        }

        .stat-label {
            color: #64748b;
            font-size: 0.875rem;
        }

        .filters {
            background: white;
            padding: 1.5rem;
            border-radius: 1rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            align-items: center;
        }

        .filters select,
        .filters input {
            padding: 0.75rem;
            border: 1px solid #e2e8f0;
            border-radius: 0.5rem;
            font-size: 0.875rem;
        }

        .filters button {
            padding: 0.75rem 1.5rem;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 0.5rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .filters button:hover {
            background: #4f46e5;
        }

        .table-container {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .table {
            margin: 0;
        }

        .table th {
            background: #f8fafc;
            font-weight: 600;
            color: #475569;
            border-bottom: 2px solid #e2e8f0;
            padding: 1.25rem;
            font-size: 0.875rem;
            text-transform: uppercase;
        }

        .table td {
            padding: 1.25rem;
            border-bottom: 1px solid #e2e8f0;
            vertical-align: middle;
        }

        .table tbody tr:hover {
            background: #f8fafc;
        }

        .badge {
            display: inline-block;
            padding: 0.5rem 1rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .badge-pending {
            background: #fef3c7;
            color: #b45309;
        }

        .badge-resolved {
            background: #dcfce7;
            color: #166534;
        }

        .badge-dismissed {
            background: #fee2e2;
            color: #991b1b;
        }

        .badge-user {
            background: #dbeafe;
            color: #0c4a6e;
        }

        .badge-post {
            background: #e9d5ff;
            color: #5b21b6;
        }

        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }

        .action-btn {
            padding: 0.5rem;
            border: 1px solid #e2e8f0;
            background: white;
            border-radius: 0.5rem;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.875rem;
        }

        .action-btn:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .pagination {
            margin-top: 2rem;
            display: flex;
            justify-content: center;
            gap: 0.5rem;
        }

        .pagination button,
        .pagination a {
            padding: 0.5rem 0.75rem;
            border: 1px solid #e2e8f0;
            background: white;
            border-radius: 0.5rem;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.875rem;
        }

        .pagination button:hover,
        .pagination a:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .pagination .active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .loading {
            text-align: center;
            padding: 2rem;
            color: #64748b;
        }

        .spinner-border {
            color: var(--primary);
        }

        .modal-backdrop {
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            border: none;
            box-shadow: 0 20px 25px rgba(0, 0, 0, 0.15);
        }

        .modal-header {
            background: linear-gradient(135deg, var(--primary) 0%, #4f46e5 100%);
            color: white;
            border: none;
        }

        .modal-title {
            font-weight: 700;
        }

        .btn-close-white {
            filter: invert(1);
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 1rem 0;
            border-bottom: 1px solid #e2e8f0;
        }

        .detail-row:last-child {
            border-bottom: none;
        }

        .detail-label {
            font-weight: 600;
            color: #475569;
        }

        .detail-value {
            color: #1e293b;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding: 1rem;
            }

            .main-content {
                margin-left: 0;
                padding: 1rem;
            }

            .filters {
                flex-direction: column;
                gap: 1rem;
            }

            .filters select,
            .filters input,
            .filters button {
                width: 100%;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<div class="sidebar">
    <div class="sidebar-header">
        <h2><i class="bi bi-shield-check"></i> Admin Panel</h2>
    </div>
    <ul class="sidebar-nav">
        <li><a href="#" class="nav-link active" data-view="mailbox"><i class="bi bi-inbox"></i> Mailbox</a></li>
        <li><a href="#" class="nav-link" data-view="user-reports"><i class="bi bi-person-exclamation"></i> User Reports</a></li>
        <li><a href="#" class="nav-link" data-view="post-reports"><i class="bi bi-file-earmark-exclamation"></i> Post Reports</a></li>
        <li><a href="#" class="nav-link" data-view="emails"><i class="bi bi-envelope"></i> Emails (TestMail)</a></li>
        <li><a href="#" class="nav-link" data-view="statistics"><i class="bi bi-graph-up"></i> Statistics</a></li>
    </ul>
</div>

<div class="main-content">
    <div class="header">
        <h1>Admin Mailbox</h1>
        <div>
            <button class="btn btn-sm btn-outline-secondary me-2" id="syncButton" onclick="syncEmails()" style="display:none;">
                <i class="bi bi-arrow-repeat"></i> Sync Emails
            </button>
            <button class="btn btn-sm btn-outline-secondary me-2" onclick="exportReports()">
                <i class="bi bi-download"></i> Export CSV
            </button>
            <button class="btn btn-sm btn-primary" onclick="refreshData()">
                <i class="bi bi-arrow-clockwise"></i> Refresh
            </button>
        </div>
    </div>

    <!-- Statistics -->
    <div class="stats-grid" id="statsContainer">
        <div class="stat-card">
            <div class="stat-value" id="totalReports">-</div>
            <div class="stat-label">Total Reports</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value" id="pendingCount">-</div>
            <div class="stat-label">Pending Reports</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value" id="resolvedCount">-</div>
            <div class="stat-label">Resolved</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value" id="dismissedCount">-</div>
            <div class="stat-label">Dismissed</div>
        </div>
    </div>

    <!-- Filters -->
    <div class="filters">
        <select id="statusFilter" onchange="applyFilters()">
            <option value="">All Status</option>
            <option value="pending">Pending</option>
            <option value="resolved">Resolved</option>
            <option value="dismissed">Dismissed</option>
        </select>

        <select id="typeFilter" onchange="applyFilters()">
            <option value="">All Types</option>
            <option value="user">User Reports</option>
            <option value="post">Post Reports</option>
        </select>

        <input type="text" id="searchInput" placeholder="Search reports..." onkeyup="applyFilters()">

        <button onclick="applyFilters()"><i class="bi bi-search"></i> Search</button>
    </div>

    <!-- Reports Table -->
    <div class="table-container">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th><input type="checkbox" id="selectAll" onchange="selectAllReports(this)"></th>
                    <th>Type</th>
                    <th>Reporter</th>
                    <th>Reported</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="reportsTable">
                <tr>
                    <td colspan="8" class="loading">
                        <div class="spinner-border spinner-border-sm" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        Loading reports...
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="pagination" id="paginationContainer"></div>
</div>

<!-- Report Details Modal -->
<div class="modal fade" id="detailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Report Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="modalBody">
                <!-- Details will be loaded here -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="markResolved" onclick="markReportResolved()">Mark as Resolved</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const API_BASE_URL = '/api/v1';
    let currentPage = 1;
    let currentFilters = {};
    let currentReportId = null;
    let detailsModal;

    // Initialize
    document.addEventListener('DOMContentLoaded', function() {
        detailsModal = new bootstrap.Modal(document.getElementById('detailsModal'));
        loadStatistics();
        loadReports();
        setupNavigation();
    });

    function setupNavigation() {
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
                this.classList.add('active');
                const view = this.dataset.view;
                loadView(view);
            });
        });
    }

    function loadView(view) {
        currentFilters = {};
        currentPage = 1;

        const header = document.querySelector('.header h1');
        document.getElementById('typeFilter').value = '';
        document.getElementById('syncButton').style.display = 'none';

        switch(view) {
            case 'mailbox':
                header.textContent = 'Admin Mailbox';
                document.getElementById('typeFilter').value = '';
                loadReports();
                break;
            case 'user-reports':
                header.textContent = 'User Reports';
                document.getElementById('typeFilter').value = 'user';
                loadReports();
                break;
            case 'post-reports':
                header.textContent = 'Post Reports';
                document.getElementById('typeFilter').value = 'post';
                loadReports();
                break;
            case 'emails':
                header.textContent = 'TestMail Inbox';
                document.getElementById('syncButton').style.display = 'inline-block';
                loadEmails();
                break;
            case 'statistics':
                header.textContent = 'Statistics & Analytics';
                loadStatistics();
                break;
        }
    }

    function loadStatistics() {
        fetch(`${API_BASE_URL}/admin/mailbox/reports/statistics`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.data) {
                document.getElementById('totalReports').textContent = data.data.total_reports;
                document.getElementById('pendingCount').textContent = data.data.by_status.pending;
                document.getElementById('resolvedCount').textContent = data.data.by_status.resolved;
                document.getElementById('dismissedCount').textContent = data.data.by_status.dismissed;
            }
        })
        .catch(error => console.error('Error loading statistics:', error));
    }

    function loadReports(page = 1) {
        currentPage = page;
        const params = new URLSearchParams({
            page: page,
            per_page: 15,
            status: document.getElementById('statusFilter').value || '',
            type: document.getElementById('typeFilter').value || '',
            search: document.getElementById('searchInput').value || '',
        });

        const tbody = document.getElementById('reportsTable');
        tbody.innerHTML = '<tr><td colspan="8" class="loading"><div class="spinner-border spinner-border-sm"></div> Loading...</td></tr>';

        fetch(`${API_BASE_URL}/admin/mailbox/reports?${params}`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.data && data.data.length > 0) {
                tbody.innerHTML = data.data.map(report => `
                    <tr>
                        <td><input type="checkbox" value="${report.id}" class="report-checkbox"></td>
                        <td><span class="badge ${report.type === 'user' ? 'badge-user' : 'badge-post'}">${report.type}</span></td>
                        <td>${report.reporter.name}</td>
                        <td>${report.type === 'user' ? report.reported_user.name : (report.reported_post?.title || 'N/A')}</td>
                        <td>${report.reason || 'N/A'}</td>
                        <td><span class="badge badge-${report.status}">${report.status}</span></td>
                        <td>${new Date(report.created_at).toLocaleDateString()}</td>
                        <td>
                            <div class="action-buttons">
                                <button class="action-btn" onclick="viewDetails(${report.id})" title="View Details">
                                    <i class="bi bi-eye"></i>
                                </button>
                                <button class="action-btn" onclick="updateStatus(${report.id}, 'pending')" title="Mark Pending">
                                    <i class="bi bi-clock"></i>
                                </button>
                                <button class="action-btn" onclick="updateStatus(${report.id}, 'resolved')" title="Mark Resolved">
                                    <i class="bi bi-check-circle"></i>
                                </button>
                                <button class="action-btn" onclick="updateStatus(${report.id}, 'dismissed')" title="Dismiss">
                                    <i class="bi bi-x-circle"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `).join('');

                renderPagination(data.pagination);
            } else {
                tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted py-4">No reports found</td></tr>';
                document.getElementById('paginationContainer').innerHTML = '';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            tbody.innerHTML = '<tr><td colspan="8" class="text-center text-danger py-4">Error loading reports</td></tr>';
        });
    }

    function renderPagination(pagination) {
        const container = document.getElementById('paginationContainer');
        let html = '';

        if (pagination.current_page > 1) {
            html += `<button onclick="loadReports(${pagination.current_page - 1})">← Previous</button>`;
        }

        for (let i = 1; i <= pagination.last_page; i++) {
            if (i === pagination.current_page) {
                html += `<button class="active">${i}</button>`;
            } else {
                html += `<button onclick="loadReports(${i})">${i}</button>`;
            }
        }

        if (pagination.current_page < pagination.last_page) {
            html += `<button onclick="loadReports(${pagination.current_page + 1})">Next →</button>`;
        }

        container.innerHTML = html;
    }

    function viewDetails(reportId) {
        fetch(`${API_BASE_URL}/admin/mailbox/reports/${reportId}`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        })
        .then(response => response.json())
        .then(data => {
            currentReportId = reportId;
            const report = data.data;
            let html = `
                <div class="detail-row">
                    <span class="detail-label">Type:</span>
                    <span class="detail-value"><span class="badge badge-${report.type}">${report.type}</span></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Status:</span>
                    <span class="detail-value"><span class="badge badge-${report.status}">${report.status}</span></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Reason:</span>
                    <span class="detail-value">${report.reason || 'N/A'}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Reporter:</span>
                    <span class="detail-value">${report.reporter.name} (${report.reporter.email})</span>
                </div>
            `;

            if (report.type === 'user' && report.reported_user) {
                html += `
                    <div class="detail-row">
                        <span class="detail-label">Reported User:</span>
                        <span class="detail-value">${report.reported_user.name} (@${report.reported_user.username})</span>
                    </div>
                `;
            } else if (report.type === 'post' && report.reported_post) {
                html += `
                    <div class="detail-row">
                        <span class="detail-label">Reported Post:</span>
                        <span class="detail-value">${report.reported_post.title}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Post Author:</span>
                        <span class="detail-value">${report.reported_post.author.name}</span>
                    </div>
                `;
            }

            html += `
                <div class="detail-row">
                    <span class="detail-label">Message:</span>
                    <span class="detail-value">${report.message}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Date:</span>
                    <span class="detail-value">${new Date(report.created_at).toLocaleString()}</span>
                </div>
            `;

            document.getElementById('modalBody').innerHTML = html;
            detailsModal.show();
        })
        .catch(error => console.error('Error:', error));
    }

    function updateStatus(reportId, status) {
        if (!confirm(`Are you sure you want to mark this report as "${status}"?`)) return;

        fetch(`${API_BASE_URL}/admin/mailbox/reports/${reportId}/status`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${getToken()}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status: status })
        })
        .then(response => response.json())
        .then(data => {
            if (data.data) {
                loadReports(currentPage);
                loadStatistics();
                alert('Report status updated successfully!');
            }
        })
        .catch(error => console.error('Error:', error));
    }

    function markReportResolved() {
        if (currentReportId) {
            updateStatus(currentReportId, 'resolved');
            detailsModal.hide();
        }
    }

    function applyFilters() {
        loadReports(1);
    }

    function selectAllReports(checkbox) {
        document.querySelectorAll('.report-checkbox').forEach(cb => cb.checked = checkbox.checked);
    }

    function exportReports() {
        const status = document.getElementById('statusFilter').value;
        const type = document.getElementById('typeFilter').value;
        const params = new URLSearchParams();
        if (status) params.append('status', status);
        if (type) params.append('type', type);

        window.open(`${API_BASE_URL}/admin/mailbox/reports/export/csv?${params}`, '_blank');
    }

    function refreshData() {
        loadStatistics();
        loadReports(currentPage);
    }

    function getToken() {
        return localStorage.getItem('token') || sessionStorage.getItem('token');
    }

    function syncEmails() {
        if (!confirm('Sync emails from TestMail? This may take a moment...')) return;

        const syncBtn = document.getElementById('syncButton');
        const originalText = syncBtn.innerHTML;
        syncBtn.innerHTML = '<i class="bi bi-hourglass-split"></i> Syncing...';
        syncBtn.disabled = true;

        fetch(`${API_BASE_URL}/admin/mailbox/emails/sync`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${getToken()}`,
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            alert(`${data.message}\nSynced: ${data.synced_count} emails`);
            loadEmails();
            syncBtn.innerHTML = originalText;
            syncBtn.disabled = false;
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error syncing emails');
            syncBtn.innerHTML = originalText;
            syncBtn.disabled = false;
        });
    }

    function loadEmails(page = 1) {
        currentPage = page;
        const params = new URLSearchParams({
            page: page,
            per_page: 15,
            email_type: document.getElementById('typeFilter').value || '',
            search: document.getElementById('searchInput').value || '',
        });

        const tbody = document.getElementById('reportsTable');
        tbody.innerHTML = '<tr><td colspan="8" class="loading"><div class="spinner-border spinner-border-sm"></div> Loading emails...</td></tr>';

        // Update table headers for emails view
        const tableHeaders = document.querySelector('table thead tr');
        tableHeaders.innerHTML = `
            <th><input type="checkbox" id="selectAll" onchange="selectAllReports(this)"></th>
            <th>Type</th>
            <th>From</th>
            <th>Subject</th>
            <th>Preview</th>
            <th>Status</th>
            <th>Date</th>
            <th>Actions</th>
        `;

        fetch(`${API_BASE_URL}/admin/mailbox/emails?${params}`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.data && data.data.length > 0) {
                tbody.innerHTML = data.data.map(email => `
                    <tr>
                        <td><input type="checkbox" value="${email.id}" class="report-checkbox"></td>
                        <td><span class="badge badge-${email.email_type}">${email.email_type}</span></td>
                        <td>${email.from}</td>
                        <td>${email.subject}</td>
                        <td>${email.body ? email.body.substring(0, 50) + '...' : 'No content'}</td>
                        <td><span class="badge ${email.is_read ? 'badge-resolved' : 'badge-pending'}">${email.is_read ? 'Read' : 'Unread'}</span></td>
                        <td>${new Date(email.received_at).toLocaleDateString()}</td>
                        <td>
                            <div class="action-buttons">
                                <button class="action-btn" onclick="viewEmailDetail(${email.id})" title="View Email">
                                    <i class="bi bi-envelope-open"></i>
                                </button>
                                <button class="action-btn" onclick="toggleEmailRead(${email.id})" title="Toggle Read">
                                    <i class="bi bi-eye"></i>
                                </button>
                                <button class="action-btn" onclick="toggleEmailArchive(${email.id})" title="Archive">
                                    <i class="bi bi-archive"></i>
                                </button>
                                <button class="action-btn" onclick="deleteEmail(${email.id})" title="Delete">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `).join('');

                renderPagination(data.pagination);
            } else {
                tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted py-4">No emails found. Click "Sync Emails" to fetch from TestMail.</td></tr>';
                document.getElementById('paginationContainer').innerHTML = '';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            tbody.innerHTML = '<tr><td colspan="8" class="text-center text-danger py-4">Error loading emails</td></tr>';
        });
    }

    function viewEmailDetail(emailId) {
        fetch(`${API_BASE_URL}/admin/mailbox/emails/${emailId}`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        })
        .then(response => response.json())
        .then(data => {
            const email = data.data;
            let html = `
                <div class="detail-row">
                    <span class="detail-label">Type:</span>
                    <span class="detail-value"><span class="badge badge-${email.email_type}">${email.email_type}</span></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">From:</span>
                    <span class="detail-value">${email.from}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">To:</span>
                    <span class="detail-value">${email.to}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Subject:</span>
                    <span class="detail-value">${email.subject}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Date:</span>
                    <span class="detail-value">${new Date(email.received_at).toLocaleString()}</span>
                </div>
                <div class="detail-row" style="flex-direction: column; align-items: flex-start;">
                    <span class="detail-label">Message:</span>
                    <span class="detail-value" style="margin-top: 10px; padding: 10px; background: #f8fafc; border-radius: 5px; max-width: 100%;">${email.body || 'No content'}</span>
                </div>
            `;

            if (email.related_report) {
                html += `
                    <div class="detail-row">
                        <span class="detail-label">Related Report:</span>
                        <span class="detail-value">${email.related_report.type} - ${email.related_report.reason}</span>
                    </div>
                `;
            }

            document.getElementById('modalBody').innerHTML = html;
            detailsModal.show();
        })
        .catch(error => console.error('Error:', error));
    }

    function toggleEmailRead(emailId) {
        fetch(`${API_BASE_URL}/admin/mailbox/emails/${emailId}/toggle-read`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${getToken()}`,
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            loadEmails(currentPage);
        })
        .catch(error => console.error('Error:', error));
    }

    function toggleEmailArchive(emailId) {
        fetch(`${API_BASE_URL}/admin/mailbox/emails/${emailId}/toggle-archive`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${getToken()}`,
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            alert('Email archived successfully');
            loadEmails(currentPage);
        })
        .catch(error => console.error('Error:', error));
    }

    function deleteEmail(emailId) {
        if (!confirm('Are you sure you want to delete this email?')) return;

        fetch(`${API_BASE_URL}/admin/mailbox/emails/${emailId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        })
        .then(response => response.json())
        .then(data => {
            alert('Email deleted successfully');
            loadEmails(currentPage);
        })
        .catch(error => console.error('Error:', error));
    }
</script>
</body>
</html>
<?php /**PATH D:\course laravel\devhub\resources\views/admin-dashboard.blade.php ENDPATH**/ ?>