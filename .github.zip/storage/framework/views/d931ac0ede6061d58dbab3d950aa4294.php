<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TestMail Mailbox</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
</head>
<body class="bg-slate-50">
    <nav class="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div class="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
            <h1 class="text-xl font-bold text-slate-900">📧 TestMail Mailbox</h1>
            <div class="text-sm text-slate-600">9gwbk</div>
        </div>
    </nav>

    <div class="max-w-6xl mx-auto px-4 py-8" x-data="mailboxApp()">
        <div class="flex gap-3 mb-6">
            <button @click="loadEmails()"
                    :disabled="loading"
                    class="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-lg font-medium flex items-center gap-2">
                <svg x-show="!loading" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                </svg>
                <svg x-show="loading" class="w-5 h-5 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                </svg>
                <span x-text="loading ? 'Loading...' : 'Refresh Emails'"></span>
            </button>
            <div class="text-sm text-slate-600 py-2" x-text="'Total: ' + emails.length + ' emails'"></div>
        </div>

        <!-- Email List -->
        <div class="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
            <template x-if="emails.length === 0">
                <div class="p-12 text-center">
                    <svg class="w-12 h-12 text-slate-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                    </svg>
                    <p class="text-slate-500 font-medium">No emails yet</p>
                </div>
            </template>

            <template x-for="(email, index) in emails" :key="index">
                <div class="border-b border-slate-200 last:border-b-0 p-4 hover:bg-slate-50 transition" x-data="{ expanded: false }">
                    <!-- Summary -->
                    <div @click="expanded = !expanded" class="cursor-pointer">
                        <div class="flex items-start gap-4">
                            <div class="flex-1 min-w-0">
                                <h3 class="font-semibold text-slate-900" x-text="email.subject || '(No Subject)'"></h3>
                                <p class="text-sm text-slate-600 mt-1" x-text="'From: ' + email.from"></p>
                                <p class="text-sm text-slate-600" x-text="'To: ' + email.to"></p>
                                <p class="text-xs text-slate-400 mt-1" x-text="formatDate(new Date(email.timestamp))"></p>
                            </div>
                            <button @click.stop="copyToClipboard(email.text || email.html)"
                                    class="px-3 py-1 text-sm bg-blue-100 hover:bg-blue-200 text-blue-700 rounded">
                                Copy
                            </button>
                        </div>
                    </div>

                    <!-- Expanded Content -->
                    <template x-if="expanded">
                        <div class="mt-4 pt-4 border-t border-slate-200 space-y-3">
                            <div>
                                <p class="text-xs font-semibold text-slate-600 mb-1">From:</p>
                                <p class="text-sm text-slate-900 font-mono" x-text="email.from"></p>
                            </div>
                            <div>
                                <p class="text-xs font-semibold text-slate-600 mb-1">To:</p>
                                <p class="text-sm text-slate-900 font-mono" x-text="email.to"></p>
                            </div>
                            <div>
                                <p class="text-xs font-semibold text-slate-600 mb-1">Subject:</p>
                                <p class="text-sm text-slate-900" x-text="email.subject || '(No Subject)'"></p>
                            </div>
                            <div>
                                <p class="text-xs font-semibold text-slate-600 mb-1">Content:</p>
                                <div class="bg-slate-50 p-3 rounded border border-slate-200 max-h-64 overflow-y-auto">
                                    <div class="text-sm text-slate-700 whitespace-pre-wrap font-mono text-xs" x-text="email.text || email.html || '(No content)'"></div>
                                </div>
                            </div>
                        </div>
                    </template>
                </div>
            </template>
        </div>
    </div>

    <script>
        function mailboxApp() {
            return {
                emails: [],
                loading: false,

                formatDate(date) {
                    const now = new Date();
                    const diff = now - date;
                    const minutes = Math.floor(diff / 60000);
                    const hours = Math.floor(diff / 3600000);
                    const days = Math.floor(diff / 86400000);

                    if (minutes < 1) return 'Just now';
                    if (minutes < 60) return `${minutes}m ago`;
                    if (hours < 24) return `${hours}h ago`;
                    if (days < 7) return `${days}d ago`;
                    return date.toLocaleDateString();
                },

                async loadEmails() {
                    this.loading = true;
                    try {
                        const response = await fetch('https://api.testmail.app/api/json');
                        const data = await response.json();

                        if (data.success && Array.isArray(data.data)) {
                            this.emails = data.data;
                        }
                    } catch (error) {
                        console.error('Error loading emails:', error);
                    } finally {
                        this.loading = false;
                    }
                },

                copyToClipboard(text) {
                    navigator.clipboard.writeText(text).then(() => {
                        alert('Copied to clipboard!');
                    });
                },

                init() {
                    this.loadEmails();
                    // Auto-refresh every 30 seconds
                    setInterval(() => this.loadEmails(), 30000);
                }
            }
        }
    </script>
</body>
</html>

<?php /**PATH D:\course laravel\devhub\resources\views/mailbox-simple.blade.php ENDPATH**/ ?>