::get<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Admin Test Mailbox - Enhanced</title>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }

        @keyframes slideInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes pulse-glow {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .animate-slide-in-down {
            animation: slideInDown 0.3s ease-out;
        }

        .animate-slide-in-up {
            animation: slideInUp 0.3s ease-out;
        }

        .pulse-glow {
            animation: pulse-glow 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }

        .scrollbar-hide::-webkit-scrollbar {
            display: none;
        }

        .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }

        .gradient-text {
            background: linear-gradient(135deg, #3b82f6, #6366f1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 min-h-screen">
    <!-- Navigation Bar -->
    <nav class="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg">
                        <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                        </svg>
                    </div>
                    <div>
                        <h1 class="text-xl font-bold text-slate-900">DevHub Admin</h1>
                        <p class="text-xs text-slate-500">Test Mailbox Manager</p>
                    </div>
                </div>
                <div class="flex items-center gap-4">
                    <div class="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-lg">
                        <div class="w-2 h-2 bg-green-500 rounded-full pulse-glow"></div>
                        <span class="text-sm font-medium text-slate-700">System Online</span>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" x-data="enhancedMailboxManager()" @keydown.escape="showFilters = false">
        <!-- Header Section -->
        <div class="mb-8 animate-slide-in-down">
            <h2 class="text-4xl font-bold gradient-text mb-2">Test Mailbox Manager</h2>
            <p class="text-slate-600 text-lg">Create and manage temporary email addresses for testing your application</p>
        </div>

        <!-- Stats Cards with Enhanced Design -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8 animate-slide-in-up">
            <!-- Total Mailboxes -->
            <div class="group bg-white rounded-xl p-6 border border-slate-200 shadow-sm hover:shadow-lg hover:border-blue-300 transition-all duration-300">
                <div class="flex items-start justify-between mb-2">
                    <div class="flex-1">
                        <p class="text-sm text-slate-600 font-medium mb-1">Total Mailboxes</p>
                        <p class="text-3xl font-bold text-slate-900" x-text="stats.totalMailboxes">0</p>
                        <p class="text-xs text-slate-400 mt-1">Active mailboxes</p>
                    </div>
                    <div class="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
                        </svg>
                    </div>
                </div>
                <div class="h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div class="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full" style="width: 65%;"></div>
                </div>
            </div>

            <!-- Total Emails -->
            <div class="group bg-white rounded-xl p-6 border border-slate-200 shadow-sm hover:shadow-lg hover:border-green-300 transition-all duration-300">
                <div class="flex items-start justify-between mb-2">
                    <div class="flex-1">
                        <p class="text-sm text-slate-600 font-medium mb-1">Total Emails</p>
                        <p class="text-3xl font-bold text-slate-900" x-text="stats.totalEmails">0</p>
                        <p class="text-xs text-slate-400 mt-1">Received emails</p>
                    </div>
                    <div class="w-12 h-12 rounded-lg bg-gradient-to-br from-green-100 to-green-200 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                        </svg>
                    </div>
                </div>
                <div class="h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div class="h-full bg-gradient-to-r from-green-500 to-green-600 rounded-full" style="width: 45%;"></div>
                </div>
            </div>

            <!-- Namespace -->
            <div class="group bg-white rounded-xl p-6 border border-slate-200 shadow-sm hover:shadow-lg hover:border-purple-300 transition-all duration-300">
                <div class="flex items-start justify-between mb-2">
                    <div class="flex-1">
                        <p class="text-sm text-slate-600 font-medium mb-1">Namespace</p>
                        <p class="text-3xl font-bold text-slate-900 truncate" x-text="namespace">-</p>
                        <p class="text-xs text-slate-400 mt-1">Identifier</p>
                    </div>
                    <div class="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-100 to-purple-200 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                        </svg>
                    </div>
                </div>
                <div class="h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div class="h-full bg-gradient-to-r from-purple-500 to-purple-600 rounded-full" style="width: 80%;"></div>
                </div>
            </div>

            <!-- Status -->
            <div class="group bg-white rounded-xl p-6 border border-slate-200 shadow-sm hover:shadow-lg hover:border-yellow-300 transition-all duration-300">
                <div class="flex items-start justify-between mb-2">
                    <div class="flex-1">
                        <p class="text-sm text-slate-600 font-medium mb-1">Status</p>
                        <div class="flex items-center gap-2">
                            <p class="text-3xl font-bold text-slate-900" x-text="status">Idle</p>
                            <div class="w-2 h-2 rounded-full" :class="status === 'Ready' ? 'bg-green-500 pulse-glow' : 'bg-yellow-500'"></div>
                        </div>
                        <p class="text-xs text-slate-400 mt-1">System state</p>
                    </div>
                    <div class="w-12 h-12 rounded-lg bg-gradient-to-br from-yellow-100 to-yellow-200 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                </div>
                <div class="h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div class="h-full bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-full" style="width: 90%;"></div>
                </div>
            </div>
        </div>

        <!-- Main Content Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Left Column - Create Mailbox -->
            <div class="lg:col-span-1 space-y-6">
                <!-- Create Mailbox Card -->
                <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                    <div class="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4">
                        <h3 class="text-lg font-semibold text-white flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                            </svg>
                            Create New Mailbox
                        </h3>
                    </div>

                    <div class="p-6">
                        <div class="space-y-4">
                            <div>
                                <label for="mailbox-tag" class="block text-sm font-medium text-slate-700 mb-2">
                                    Mailbox Tag (Optional)
                                </label>
                                <input
                                    type="text"
                                    id="mailbox-tag"
                                    x-model="formData.tag"
                                    placeholder="e.g., registration-test, password-reset"
                                    class="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                                >
                                <p class="text-xs text-slate-500 mt-1">💡 Leave empty for auto-generated tag with timestamp</p>
                            </div>

                            <button
                                @click="createMailbox()"
                                :disabled="loading"
                                class="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold py-2.5 rounded-lg transition flex items-center justify-center gap-2 shadow-md hover:shadow-lg"
                            >
                                <svg x-show="!loading" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                                </svg>
                                <svg x-show="loading" class="w-5 h-5 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                                </svg>
                                <span x-text="loading ? 'Creating...' : 'Create Mailbox'"></span>
                            </button>
                        </div>

                        <!-- Created Mailbox Display -->
                        <template x-if="createdMailbox">
                            <div class="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg animate-slide-in-up">
                                <div class="flex items-start gap-3 mb-3">
                                    <svg class="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                                    </svg>
                                    <p class="text-sm font-semibold text-green-800">Mailbox Created Successfully</p>
                                </div>
                                <div class="space-y-3">
                                    <div>
                                        <p class="text-xs text-green-700 mb-1">Email Address</p>
                                        <div class="flex gap-2">
                                            <code class="flex-1 bg-white px-3 py-2 rounded border border-green-200 text-xs text-slate-900 overflow-auto font-mono">
                                                <span x-text="createdMailbox.mailbox"></span>
                                            </code>
                                            <button
                                                @click="copyToClipboard(createdMailbox.mailbox)"
                                                class="px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded text-xs font-semibold transition"
                                            >
                                                📋 Copy
                                            </button>
                                        </div>
                                    </div>
                                    <div>
                                        <p class="text-xs text-green-700 mb-1">Tag</p>
                                        <p class="text-sm font-mono text-slate-900 bg-white px-3 py-2 rounded border border-green-200" x-text="createdMailbox.tag"></p>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                    <div class="bg-gradient-to-r from-slate-600 to-slate-700 px-6 py-4">
                        <h3 class="text-lg font-semibold text-white flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                            </svg>
                            Quick Actions
                        </h3>
                    </div>
                    <div class="p-6 space-y-2">
                        <button
                            @click="fetchStatus()"
                            class="w-full text-left px-4 py-3 rounded-lg hover:bg-slate-100 transition text-slate-700 font-medium text-sm flex items-center gap-3"
                        >
                            <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                            </svg>
                            <span>Refresh Status</span>
                        </button>
                        <button
                            @click="fetchEmails()"
                            class="w-full text-left px-4 py-3 rounded-lg hover:bg-slate-100 transition text-slate-700 font-medium text-sm flex items-center gap-3"
                        >
                            <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                            </svg>
                            <span>Load Emails</span>
                        </button>
                        <button
                            @click="clearForm()"
                            class="w-full text-left px-4 py-3 rounded-lg hover:bg-slate-100 transition text-slate-700 font-medium text-sm flex items-center gap-3"
                        >
                            <svg class="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                            <span>Clear Form</span>
                        </button>
                    </div>
                </div>

                <!-- Info Card -->
                <div class="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-200 p-4">
                    <p class="text-sm text-blue-900 font-semibold mb-2">💡 Pro Tips</p>
                    <ul class="text-xs text-blue-800 space-y-1.5">
                        <li>✓ Use descriptive tags for better organization</li>
                        <li>✓ Emails auto-refresh every 30 seconds</li>
                        <li>✓ Copy email address to test quickly</li>
                        <li>✓ Expand emails to see full content</li>
                    </ul>
                </div>
            </div>

            <!-- Right Column - Emails List -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                    <!-- Header with Filter -->
                    <div class="bg-gradient-to-r from-green-600 to-emerald-600 px-6 py-4">
                        <div class="flex items-center justify-between">
                            <h3 class="text-lg font-semibold text-white flex items-center gap-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                                </svg>
                                Received Emails
                            </h3>
                            <div class="flex items-center gap-3">
                                <span class="bg-white bg-opacity-20 text-white px-3 py-1 rounded-full text-sm font-semibold" x-text="emails.length + ' ' + (emails.length === 1 ? 'email' : 'emails')"></span>
                                <button
                                    @click="showFilters = !showFilters"
                                    class="p-2 rounded-lg bg-white bg-opacity-20 hover:bg-opacity-30 text-white transition"
                                    title="Filter emails"
                                >
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Emails List -->
                    <div class="divide-y divide-slate-200 max-h-[600px] overflow-y-auto scrollbar-hide">
                        <!-- Empty State -->
                        <template x-if="emails.length === 0">
                            <div class="p-12 text-center">
                                <div class="inline-flex items-center justify-center w-16 h-16 bg-slate-100 rounded-full mb-4">
                                    <svg class="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
                                    </svg>
                                </div>
                                <p class="text-slate-600 font-semibold text-lg">No emails yet</p>
                                <p class="text-slate-500 text-sm mt-1">Create a mailbox and send test emails to see them here</p>
                                <button
                                    @click="fetchEmails()"
                                    class="mt-4 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm font-medium transition"
                                >
                                    🔄 Refresh Now
                                </button>
                            </div>
                        </template>

                        <!-- Email Items -->
                        <template x-for="(email, index) in emails" :key="index">
                            <div class="p-4 hover:bg-slate-50 transition" x-data="{ expanded: false }">
                                <div @click="expanded = !expanded" class="cursor-pointer select-none">
                                    <div class="flex items-start gap-4">
                                        <!-- Email Icon/Status -->
                                        <div class="flex-shrink-0 mt-1">
                                            <div class="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-100 to-blue-100 flex items-center justify-center">
                                                <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8"></path>
                                                </svg>
                                            </div>
                                        </div>

                                        <!-- Email Content -->
                                        <div class="flex-1 min-w-0">
                                            <div class="flex items-center gap-2 mb-1 flex-wrap">
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
                                                    <span x-text="email.from.split('@')[0]" class="truncate max-w-[150px]"></span>
                                                </span>
                                                <svg class="w-3 h-3 text-slate-400" fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                                </svg>
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                                                    <span x-text="email.to.split('@')[0]" class="truncate max-w-[150px]"></span>
                                                </span>
                                            </div>
                                            <h4 class="text-sm font-semibold text-slate-900 truncate" x-text="email.subject || '(No Subject)'"></h4>
                                            <div class="flex items-center gap-3 mt-1 text-xs text-slate-500">
                                                <span x-text="'From: ' + email.from"></span>
                                                <span class="text-slate-300">•</span>
                                                <span x-text="formatDate(new Date(email.created_at || email.ts))"></span>
                                            </div>
                                        </div>

                                        <!-- Action Buttons -->
                                        <div class="flex items-center gap-1 flex-shrink-0">
                                            <button
                                                @click.stop="copyToClipboard(email.text || email.html || 'No content')"
                                                class="p-2 text-slate-500 hover:bg-slate-100 rounded transition"
                                                title="Copy content"
                                            >
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                                                </svg>
                                            </button>
                                            <button
                                                @click.stop="deleteEmail(email)"
                                                class="p-2 text-red-500 hover:bg-red-50 rounded transition"
                                                title="Delete email"
                                            >
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Expanded Content -->
                                    <template x-if="expanded">
                                        <div class="mt-4 pt-4 border-t border-slate-200 space-y-3 animate-slide-in-up">
                                            <div class="grid grid-cols-2 gap-4">
                                                <div>
                                                    <p class="text-xs font-semibold text-slate-600 mb-1">From:</p>
                                                    <p class="text-sm text-slate-900 font-mono bg-slate-50 p-2 rounded border border-slate-200" x-text="email.from"></p>
                                                </div>
                                                <div>
                                                    <p class="text-xs font-semibold text-slate-600 mb-1">To:</p>
                                                    <p class="text-sm text-slate-900 font-mono bg-slate-50 p-2 rounded border border-slate-200" x-text="email.to"></p>
                                                </div>
                                            </div>
                                            <div>
                                                <p class="text-xs font-semibold text-slate-600 mb-1">Subject:</p>
                                                <p class="text-sm text-slate-900 bg-slate-50 p-2 rounded border border-slate-200" x-text="email.subject || '(No Subject)'"></p>
                                            </div>
                                            <div>
                                                <p class="text-xs font-semibold text-slate-600 mb-1">Content:</p>
                                                <div class="bg-slate-50 border border-slate-200 rounded p-3 max-h-64 overflow-y-auto">
                                                    <div class="text-sm text-slate-700 font-mono text-xs whitespace-pre-wrap break-words" x-text="email.text || email.html || '(No content)'"></div>
                                                </div>
                                            </div>
                                            <div class="flex gap-2 pt-2">
                                                <button
                                                    @click.stop="copyToClipboard(email.text || email.html || 'No content')"
                                                    class="flex-1 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-xs font-semibold transition"
                                                >
                                                    📋 Copy Content
                                                </button>
                                            </div>
                                        </div>
                                    </template>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
            </div>
        </div>

        <!-- Alert Messages -->
        <template x-if="alert.show">
            <div class="fixed bottom-4 right-4 rounded-lg px-6 py-4 shadow-lg text-white font-medium flex items-center gap-3 animate-slide-in-up z-50" :class="alert.type === 'success' ? 'bg-green-600' : 'bg-red-600'">
                <svg v-if="alert.type === 'success'" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                </svg>
                <svg v-else class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
                </svg>
                <span x-text="alert.message"></span>
            </div>
        </template>
    </div>

    <script>
        function enhancedMailboxManager() {
            return {
                formData: { tag: '' },
                emails: [],
                createdMailbox: null,
                loading: false,
                namespace: 'Loading...',
                stats: { totalMailboxes: 0, totalEmails: 0 },
                status: 'Initializing',
                showFilters: false,
                alert: { show: false, message: '', type: 'success' },

                formatDate(date) {
                    const now = new Date();
                    const diff = now - date;
                    const minutes = Math.floor(diff / 60000);
                    const hours = Math.floor(diff / 3600000);
                    const days = Math.floor(diff / 86400000);

                    if (minutes < 1) return 'Just now';
                    if (minutes < 60) return `${minutes}m ago`;
                    if (hours < 24) return `${hours}h ago`;
                    if (days < 7) return `${days}d ago`;
                    return date.toLocaleDateString();
                },

                async createMailbox() {
                    this.loading = true;
                    try {
                        const response = await fetch('/api/v1/admin/mailbox/create', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content || ''
                            },
                            body: JSON.stringify({ tag: this.formData.tag || undefined })
                        });

                        const data = await response.json();
                        if (data.success) {
                            this.createdMailbox = data.data;
                            this.showAlert('✓ Mailbox created successfully!', 'success');
                            this.formData.tag = '';
                            await this.fetchStatus();
                        } else {
                            this.showAlert(data.message || 'Failed to create mailbox', 'error');
                        }
                    } catch (error) {
                        this.showAlert('✗ Error: ' + error.message, 'error');
                    } finally {
                        this.loading = false;
                    }
                },

                async fetchEmails() {
                    try {
                        const response = await fetch('/api/v1/admin/mailbox/emails');
                        const data = await response.json();
                        if (data.success) {
                            // Handle TestMail API response format
                            // API returns: { success, message, data: { emails: [...] } }
                            const emailsData = data.data?.emails || data.data || [];
                            this.emails = Array.isArray(emailsData) ? emailsData : [];
                            this.stats.totalEmails = this.emails.length;
                        }
                    } catch (error) {
                        this.showAlert('✗ Error loading emails: ' + error.message, 'error');
                    }
                },

                async fetchStatus() {
                    try {
                        const response = await fetch('/api/v1/admin/mailbox/status');
                        const data = await response.json();
                        if (data.success) {
                            this.status = 'Ready';
                            this.namespace = data.data.namespace || 'Unknown';
                        }
                    } catch (error) {
                        this.status = 'Error';
                    }
                },

                deleteEmail(email) {
                    if (!confirm('Are you sure you want to delete this email?')) return;
                    this.emails = this.emails.filter(e => e !== email);
                    this.stats.totalEmails = this.emails.length;
                    this.showAlert('✓ Email deleted', 'success');
                },

                copyToClipboard(text) {
                    navigator.clipboard.writeText(text).then(() => {
                        this.showAlert('✓ Copied to clipboard!', 'success');
                    }).catch(() => {
                        this.showAlert('✗ Failed to copy', 'error');
                    });
                },

                clearForm() {
                    this.formData.tag = '';
                    this.createdMailbox = null;
                    this.showAlert('✓ Form cleared', 'success');
                },

                showAlert(message, type) {
                    this.alert = { show: true, message, type };
                    setTimeout(() => { this.alert.show = false; }, 3000);
                },

                init() {
                    this.fetchStatus();
                    this.fetchEmails();
                    setInterval(() => this.fetchEmails(), 30000);
                }
            }
        }
    </script>
</body>
</html>

<?php /**PATH D:\course laravel\devhub\resources\views/admin-reports-enhanced.blade.php ENDPATH**/ ?>