# GoogleAuthService Documentation

## Overview

The `GoogleAuthService` is a dedicated service class that handles all Google authentication logic for the DevHub application. It follows Laravel best practices by separating business logic from controllers.

## Location

```
app/Services/GoogleAuthService.php
```

## Purpose

- Verify Google ID tokens
- Extract user data from Google payloads
- Create or update users based on Google authentication
- Generate JWT tokens for authenticated users
- Centralize Google authentication logic

## Public Methods

### `authenticateWithIdToken(string $idToken): array`

Main method for authenticating users with a Google ID token.

**Parameters:**
- `$idToken` (string): The Google ID token from the mobile app

**Returns:**
```php
[
    'success' => true|false,
    'message' => string,
    'data' => [
        'user' => User,
        'token' => string,
        'token_type' => 'bearer',
        'expires_in' => int
    ],
    'error' => string|null
]
```

**Example Usage:**
```php
$result = $googleAuthService->authenticateWithIdToken($request->id_token);

if ($result['success']) {
    $user = $result['data']['user'];
    $token = $result['data']['token'];
}
```

### `verifyIdToken(string $idToken): array|false`

Verifies a Google ID token and returns the payload.

**Parameters:**
- `$idToken` (string): The Google ID token to verify

**Returns:**
- `array`: The verified payload if successful
- `false`: If verification fails

**Example:**
```php
$payload = $googleAuthService->verifyIdToken($idToken);

if ($payload) {
    $email = $payload['email'];
    $name = $payload['name'];
}
```

### `isEmailVerified(array $payload): bool`

Checks if the email in the Google payload is verified.

**Parameters:**
- `$payload` (array): The Google token payload

**Returns:**
- `bool`: True if email is verified, false otherwise

**Example:**
```php
if ($googleAuthService->isEmailVerified($payload)) {
    // Email is verified
}
```

### `extractUserData(array $payload): array`

Extracts and formats user data from Google payload.

**Parameters:**
- `$payload` (array): The Google token payload

**Returns:**
```php
[
    'email' => string,
    'name' => string,
    'avatar' => string|null,
    'google_id' => string,
    'given_name' => string|null,
    'family_name' => string|null
]
```

**Example:**
```php
$userData = $googleAuthService->extractUserData($payload);
echo $userData['email']; // user@example.com
```

### `findOrCreateUser(array $userData): User`

Finds an existing user or creates a new one based on email.

**Parameters:**
- `$userData` (array): Extracted user data from Google

**Returns:**
- `User`: The found or created user model

**Example:**
```php
$user = $googleAuthService->findOrCreateUser($userData);
echo $user->name; // John Doe
```

### `generateToken(User $user, int $ttlMinutes = 43200): string`

Generates a JWT token for the user.

**Parameters:**
- `$user` (User): The user model
- `$ttlMinutes` (int): Token time-to-live in minutes (default: 30 days)

**Returns:**
- `string`: The JWT token

**Example:**
```php
// Generate token with 7 days expiration
$token = $googleAuthService->generateToken($user, 60 * 24 * 7);
```

## Protected Methods

### `updateExistingUser(User $user, array $userData): User`

Updates an existing user's Google information.

### `createNewUser(array $userData): User`

Creates a new user from Google data.

### `generateUniqueUsername(string $email): string`

Generates a unique username from an email address.

## Features

### ✅ Token Verification
- Uses Google's official client library
- Validates token signature and expiration
- Logs verification failures

### ✅ Email Verification Check
- Ensures email is verified by Google
- Prevents unverified email logins
- Logs unverified attempts

### ✅ User Management
- Creates new users automatically
- Updates existing users' Google info
- Handles username collisions
- Sets secure random passwords

### ✅ Logging
- Logs successful logins
- Logs new user creation
- Logs errors with stack traces
- Tracks email verification issues

### ✅ Security
- 32-character secure random passwords
- Unique username generation
- Email verification enforcement
- Comprehensive error handling

## Controller Integration

The service is injected into the controller via dependency injection:

```php
class SocialiteMediaController
{
    public function __construct(
        protected GoogleAuthService $googleAuthService
    ) {}

    public function loginGoogleForMobile(Request $request): JsonResponse
    {
        $request->validate([
            'id_token' => ['required', 'string'],
        ]);

        $result = $this->googleAuthService->authenticateWithIdToken($request->id_token);

        if (!$result['success']) {
            return response()->json([
                'success' => false,
                'message' => $result['message'],
                'error' => $result['error']
            ], 401);
        }

        return response()->json([
            'success' => true,
            'message' => $result['message'],
            'data' => [
                'user' => new UserResource($result['data']['user']),
                'token' => $result['data']['token'],
                'token_type' => $result['data']['token_type'],
                'expires_in' => $result['data']['expires_in']
            ]
        ], 200);
    }
}
```

## Configuration

The service requires the following configuration in `config/services.php`:

```php
'google' => [
    'client_id' => env('GOOGLE_CLIENT_ID'),
    'client_secret' => env('GOOGLE_CLIENT_SECRET'),
    'redirect' => env('GOOGLE_REDIRECT_URL'),
],
```

And in your `.env` file:

```env
GOOGLE_CLIENT_ID=your-client-id.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=your-client-secret
GOOGLE_REDIRECT_URL=https://your-domain.com/api/v1/auth/google/callback
```

## Error Handling

The service returns standardized error responses:

### Invalid Token
```php
[
    'success' => false,
    'message' => 'Invalid Google token',
    'error' => 'Token verification failed'
]
```

### Unverified Email
```php
[
    'success' => false,
    'message' => 'Email not verified with Google',
    'error' => 'Please verify your email with Google first'
]
```

## Testing

Example test case:

```php
public function test_authenticate_with_valid_token()
{
    $googleAuthService = new GoogleAuthService();
    
    // Mock or use real test token
    $result = $googleAuthService->authenticateWithIdToken($validToken);
    
    $this->assertTrue($result['success']);
    $this->assertInstanceOf(User::class, $result['data']['user']);
    $this->assertIsString($result['data']['token']);
}
```

## Benefits of Service Layer

1. **Separation of Concerns**: Controller handles HTTP, service handles business logic
2. **Reusability**: Can be used by multiple controllers or commands
3. **Testability**: Easier to unit test isolated logic
4. **Maintainability**: Changes to Google auth logic in one place
5. **Readability**: Controller methods are cleaner and easier to understand
6. **Single Responsibility**: Each method has one clear purpose

## Future Enhancements

Potential improvements:

- Add caching for verified tokens
- Support for Google token refresh
- Rate limiting for authentication attempts
- Multi-factor authentication support
- OAuth2 scope management
- Batch user import from Google

## Related Files

- Controller: `app/Http/Controllers/V1/Auth/SocialiteMediaController.php`
- Model: `app/Models/User.php`
- Resource: `app/Http/Resources/UserResource.php`
- Config: `config/services.php`
- Routes: `routes/api.php`

## Logging

The service logs the following events:

- Invalid token attempts
- Unverified email attempts
- New user creation
- Existing user login
- Token verification failures
- General authentication errors

Check logs at: `storage/logs/laravel.log`

## Dependencies

- `google/apiclient`: ^2.15
- `tymon/jwt-auth`: ^2.0
- `laravel/framework`: ^12.0

## Support

For issues or questions:
- Check `GOOGLE_SIGN_IN_MOBILE.md` for implementation guide
- Check `GOOGLE_SIGN_IN_QUICK_REF.md` for quick reference
- Review Laravel logs for error details
- Verify Google Client ID configuration

