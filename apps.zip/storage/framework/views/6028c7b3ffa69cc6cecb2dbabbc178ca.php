<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
</head>

<body>
    h1ello world
    <script src="https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js" defer></script>
    <script>
        window.OneSignalDeferred = window.OneSignalDeferred || [];
        OneSignalDeferred.push(async function (OneSignal) {
            await OneSignal.init({
                appId: "88efb367-3555-484e-826d-cbc27f26b852",
            });
            console.log(OneSignal.User);
        });
    </script>
</body>

</html>
<?php /**PATH D:\course laravel\devhub\resources\views/welcome.blade.php ENDPATH**/ ?>