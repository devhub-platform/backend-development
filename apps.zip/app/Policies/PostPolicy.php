<?php

namespace App\Policies;

use App\Models\Post;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PostPolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user)
    {
        return true;
    }

    public function view(User $user, Post $post)
    {
        $author = $post->user ?? $post->user()->first();
        if ($author && $user->isBlockedWith($author)) {
            return false;
        }

        return true;
    }

    public function create(User $user)
    {
        return true;
    }

    public function update(User $user, Post $post)
    {
        return $post->user_id == $user->id;
    }

    public function delete(User $user, Post $post)
    {
        return $post->user_id == $user->id;
    }

    public function restore(User $user, Post $post)
    {
        return $user->id === $post->user_id;
    }

    public function forceDelete(User $user, Post $post)
    {
        return $post->user_id === $user->id;
    }

    public function userPosts(User $user)
    {
        return true;
    }

    public function search(User $user)
    {
        return true;
    }

    public function archive(User $user, Post $post)
    {
        return $user->id == $post->user_id;
    }

    public function summarize(Post $post)
    {
        return true;
    }
}
