<?php

use App\Models\Post;
use App\Models\User;
use Illuminate\Support\Str;


User::find(5)->username;


