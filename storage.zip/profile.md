<div align="center">
  <img src="https://readme-typing-svg.herokuapp.com?font=Ubuntu+Mono&weight=600&size=28&pause=1000&color=2F81F7&center=true&vCenter=true&width=600&lines=Youssef+Ahmed+%7C+Backend+Developer;Laravel+%7C+PHP+%7C+API+Development;Building+Scalable+Web+Solutions;Clean+Code+%7C+Best+Practices" alt="Typing SVG" />
</div>

<h1 align="center"> <code>Junior Backend Laravel Developer</code></h1>
<h3 align="center"><code>Crafting Robust Web Solutions from Egypt 🇪🇬</code></h3>

<p align="center" aria-label="Profile statistics">
  <a href="https://github.com/youssef-ahmed-cs" target="_blank" rel="noopener noreferrer" title="View GitHub profile">
    <img src="https://img.shields.io/github/followers/youssef-ahmed-cs?style=for-the-badge&logo=github&color=0077B5" alt="GitHub followers" style="margin-right:8px; vertical-align:middle;" />
  </a>
  <a href="https://komarev.com/ghpvc/?username=youssef-ahmed-cs" target="_blank" rel="noopener noreferrer" title="Profile views">
    <img src="https://komarev.com/ghpvc/?username=youssef-ahmed-cs&label=Profile%20Views&color=0077B5&style=for-the-badge&logo=eye" alt="Profile views" style="margin-right:8px; vertical-align:middle;" />
  </a>
  <img src="https://img.shields.io/badge/Focus-Backend%20Development-0077B5?style=for-the-badge&logo=server" alt="Focus: Backend Development" title="Focus: Backend Development" style="vertical-align:middle;" />
</p>

### About Me

- Learning *Advanced Laravel & Vue.js*
- Ask me about *Laravel, PHP, Web Development, API Design*

---

### Connect With Me

<div align="center">
  <!-- LinkedIn https://www.linkedin.com/in/youssef-ahmed-cs/ -->
  <a href="https://www.linkedin.com/in/youssef-ahmed-cs" target="_blank">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linkedin/linkedin-original.svg" width="48" height="48" alt="LinkedIn" />
  </a>

  <!-- WhatsApp -->
  <a href="https://wa.me/201277672245" target="_blank">
<img width="48" height="48" src="https://img.icons8.com/color/48/whatsapp--v1.png" alt="whatsapp--v1"/>  </a>

  <!-- Gmail -->
  <a href="mailto:youssef.ahmed.fci@gmail.com" target="_blank">
<img width="48" height="48" src="https://img.icons8.com/color/48/gmail-new.png" alt="gmail-new"/> 
  </a>

  <a href="https://x.com/YOUSEF_AHMED_CS?t=Xe3V0M7TesTGS91NB14lAQ&s=09" target="_blank">
<img width="48" height="48" src="https://img.icons8.com/fluency/48/twitter.png" alt="twitter"/>  </a>

  <!-- Facebook -->
<a href="https://www.facebook.com/USERNAME" target="_blank">
<img width="48" height="48" src="https://img.icons8.com/color/48/facebook-new.png" alt="facebook-new"/></a>
</div>

<br>
<em><b>Love connecting with different people!</b> <br>
Say <b>hi</b>, I'll be happy to meet you! </em>

---

### Tech Stack & Tools

<details open>
<summary><b>🔹 Backend & Frameworks</b></summary>
<br>
<p>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/laravel/laravel-original.svg" width="40" title="Laravel" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg" width="40" title="PHP" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/composer/composer-original.svg" width="40" title="Composer" />
<img width="40" height="40" src="https://img.icons8.com/color/48/symfony.png" alt="symfony"/>
  <img width="40" height="40" src="https://img.icons8.com/color/48/net-framework.png" alt="net-framework"/> 
<img width="48" height="48" src="https://img.icons8.com/fluency/48/flask.png" alt="flask"/></p>
</details>

<details open>
<summary><b>🔹 Frontend & Styling</b></summary>
<br>
<p>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vuejs/vuejs-original.svg" width="40" title="Vue.js" />
<img width="48" height="48" src="https://img.icons8.com/color/48/javascript--v1.png" alt="javascript--v1"/> 
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg" width="40" title="Bootstrap" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" width="40" title="HTML5" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" width="40" title="CSS3" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/tailwindcss/tailwindcss-original.svg" width="40" title="Tailwind CSS" />

</p>
</details>

<details open>
<summary><b>Programming Languages</b></summary>
<br>
<p>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg" width="48" title="PHP" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" width="40" title="Python" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" width="40" title="Java" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/cplusplus/cplusplus-original.svg" width="40" title="C++" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg" width="40" title="C#" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" width="40" title="JavaScript" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-original.svg" width="40" title="TypeScript" />
  <img width="48" height="48" src="https://img.icons8.com/color/48/kotlin.png" alt="kotlin"/>
  <img width="48" height="48" src="https://img.icons8.com/3d-fluency/94/console.png" alt="console"/></details>

<details open>
<summary><b>Databases</b></summary>
<br>
<p>
  <img width="48" height="48" src="https://img.icons8.com/fluency/48/database--v1.png" alt="database--v1"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" width="40" title="MySQL" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-original.svg" width="40" title="PostgreSQL" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/microsoftsqlserver/microsoftsqlserver-plain.svg" width="40" title="SQL Server" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/sqlite/sqlite-original.svg" width="40" title="SQLite" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/redis/redis-original.svg" width="40" title="Redis" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original.svg" width="40" title="MongoDB" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/oracle/oracle-original.svg" width="40" title="Oracle Database" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mariadb/mariadb-original.svg" width="40" title="MariaDB" />
  <img width="48" height="48" src="https://img.icons8.com/color/48/amazon-s3.png" alt="amazon-s3"/>
</p>
</details>

<details open>
<summary><b>DevOps & Tools</b></summary>
<br>
<p>
  <img width="48" height="48" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg" width="40" title="Git" />
  <img width="48" height="48" src="https://img.icons8.com/3d-fluency/94/github.png" alt="github"/> 
  <img width="48" height="48" src="https://img.icons8.com/fluency/48/docker.png" alt="docker"/>
  <img width="48" height="48" src="https://img.icons8.com/clouds/100/api.png" alt="api"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nginx/nginx-original.svg" width="40" title="Nginx" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linux/linux-original.svg" width="40" title="Linux" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/apache/apache-original.svg" width="40" title="Apache" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/phpstorm/phpstorm-original.svg" width="40" title="PhpStorm" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/webstorm/webstorm-original.svg" width="40" title="WebStorm" />
  <img width="48" height="48" src="https://img.icons8.com/color/48/amazon-web-services.png" alt="amazon-web-services"/>
  <img width="48" height="48" src="https://img.icons8.com/color/48/ubuntu--v1.png" alt="ubuntu--v1"/>
</p>
</details>


<details open>
<summary><b>Design & Other Tools</b></summary>
<br>
<p>
  <img src="https://raw.githubusercontent.com/simple-icons/simple-icons/develop/icons/warp.svg" width="40" title="Warp Terminal" />
  <img width="48" height="48" src="https://img.icons8.com/fluency/48/github-copilot.png" alt="github-copilot"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/figma/figma-original.svg" width="40" title="Figma" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/illustrator/illustrator-plain.svg" width="40" title="Illustrator" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/photoshop/photoshop-plain.svg" width="40" title="Photoshop" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postman/postman-original.svg" width="40" title="Postman" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg" width="40" title="VS Code" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/slack/slack-original.svg" width="40" title="Slack" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/notion/notion-original.svg" width="40" title="Notion" />
  <img width="48" height="48" src="https://img.icons8.com/fluency/48/brave-web-browser.png" alt="brave-web-browser"/> 
  <img width="48" height="48" src="https://img.icons8.com/fluency/48/claude-ai.png" alt="claude-ai"/>
  <img width="48" height="48" src="https://img.icons8.com/fluency/48/sublime-text.png" alt="sublime-text"/>
  <img width="48" height="48" src="https://img.icons8.com/fluency/48/gemini-ai.png" alt="gemini-ai"/>

</p>
</details>

---

### GitHub Trophies

<div align="center">
  <a href="https://github.com/youssef-ahmed-cs" target="_blank" rel="noopener noreferrer" aria-label="Open GitHub profile youssef-ahmed-cs">
    <figure style="display:inline-block; margin:0;">
      <img src="https://github-profile-trophy.vercel.app/?username=youssef-ahmed-cs&theme=tokyonight&no-frame=false&no-bg=false&margin-w=4" alt="GitHub Trophies for youssef-ahmed-cs" title="GitHub Trophies — youssef-ahmed-cs" loading="lazy" width="600" />
      <figcaption style="font-size:12px; color:#6b7280; margin-top:8px;">Click to view profile</figcaption>
    </figure>
  </a>
</div>

---

### Contribution Graph

<div align="center">
  <img src="https://github-readme-activity-graph.vercel.app/graph?username=youssef-ahmed-cs&theme=tokyo-night" alt="Contribution Graph" />
</div>
